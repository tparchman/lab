#!/usr/bin/perl

$infile = shift @ARGV;
open(IN, $infile) or die "failed to open infile";
open(OUT, "> illumina_oligos.txt") or die "failed to open outfile";

<IN>; ## discard header
while(<IN>){
    chomp;
    @line = split /,/;
    $seq = $line[3];
    $seq =~ tr/[a-z]/[A-Z]/;
    print OUT ">$line[2]\n$seq\n";
}
