## bowtie2-build MK085509.1.fasta juniper_chloro
bowtie2-build MK085509.1.fasta ../juniper_chloro
