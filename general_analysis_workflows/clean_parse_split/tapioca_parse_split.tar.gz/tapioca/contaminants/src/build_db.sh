## bowtie2-build nc_000913.2_ecoli_k-12.fasta ecoli-k-12
bowtie2-build /data/public/genomes/bacteria/Wolbachia_NC_006833.fasta /data/public/contaminants/Wolbachia_NC_006833
