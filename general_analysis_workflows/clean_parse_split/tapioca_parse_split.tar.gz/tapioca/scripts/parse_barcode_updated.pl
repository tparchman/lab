#!/usr/bin/perl

## This program removes barcode sequences from fastq reads and places them
## in the name. This program also removes adpater sequences from the 3' end.
## Qual scores corresponding to the removed barcode and adapter are removed
## as well. The reads are separted into separate files based on species and
## enzymes (for the pines). This part of the code will not be necessary in
## most cases where each lane contains a single experiment. Sequences not
## matching any barcodes are written to a separate file (miderrors.txt).

## This now includes a function for correcting barcodes that are off by 1.

## zg 4ix11 - This is a new version that will work with 8, 9, or 10 bp barcoes.
## cab 8nov12 -- lines are read in groups of 4, skipping the regular expression to track where we are
## cab 10nov12 -- use Levenshtein distance to find barcode correction (faster)
## cab 16dec12 -- catch instances where raw data are not in a set of four lines
## [update] -- fixed the resync loop for malformed fastq records (it never advanced
##             and never stopped at EOF); split read outcomes into mutually
##             exclusive counters; report gives counts and % of total reads and
##             lists low-coverage samples; per-sample table is a separate CSV.

## usage:   parse_barcodes_updated.pl barcodefile fastqfile MACHINENAME
## example: parse_barcodes_updated.pl barcodes_manacus1.csv rawreads_flowcell1/UW_1.fastq HWI-ST123
##          (MACHINENAME is whatever follows the @ on your fastq header lines)

use warnings;
use Text::LevenshteinXS 'distance';

unless (scalar @ARGV > 2){
    die "I need three arguments to run: barcodefile fastqfile MACHINENAME";
}
my $barcodes = shift(@ARGV);
my $infile = shift (@ARGV);
my $devicename = shift (@ARGV);
unless($devicename){
	die "Please provide a machine name that appears after \@ on info lines of fastq file";
}

open (INFILE, $infile) or die "You are a dummy";
open (MIDS, $barcodes) or die "Could not open MID file";

my %mids;
my %midsctr;
my %seen_sample;  ## to warn if a sample name is used on more than one barcode
<MIDS>; ## get rid of top line in MIDS file
while(<MIDS>){
    chomp;
    @line = split ',', $_;
    $line[1] =~ tr/[a-z]/[A-Z]/; ## catch lower-case barcode input and make it uppercase
    $bcode = "$line[1]"."CAATTC"; # add restriction site, not necessary if barcode + res. site is included
    warn "Warning: sample name '$line[2]' is used on more than one barcode; per-sample report assumes 1:1\n" if $seen_sample{$line[2]}++;
    $mids{$bcode} = $line[2];
    $midsctr{$bcode} = 0; ## initialize counters to zero
}
close (MIDS) or die "Could not close MIDS\n";

@barcodes = sort keys %mids;

$infile =~ s/.*\/([\w.]+fq)$/$1/;  ## simplify file name by
				      ## dropping leading folder name
$infile =~ s/.*\/([\w.]+fa)$/$1/;
$infile =~ s/.*\/([\w.]+fastq)$/$1/;

open (SEQ, "> parsed_"."$infile") or
    die "Could not open SEQ\n";
open (CRAP, "> miderrors_"."$infile") or die "Could not open CRAP\n";

my $getit = 0;
my $mseprob = 0;      # reads in which the 3' adapter was found and trimmed (overlaps with outcomes)
my $seqcnt = 0;       # total reads processed (records that passed the header check)
my $goodmid = 0;
my $goodmidctr = 0;   # reads written to parsed file (exact + corrected)
my $badmidctr = 0;    # uncorrectable barcode -> miderrors file
my $adlen;
my $adrem = 0;
my @ad;
my $bclen = 16; # 10 bc and 6 res. site
my $qline;
my $tooshort = 0;     # too short to test for a barcode

## outcome counters (each read lands in exactly one of these six)
my $exact_written     = 0;  # exact barcode match, written
my $corrected_written = 0;  # corrected barcode, written
my $exact_empty       = 0;  # exact barcode match, nothing left after removal, dropped
my $corrected_empty   = 0;  # corrected barcode, nothing left after removal, dropped
## ($badmidctr and $tooshort are the other two)

## input file integrity counters (not read outcomes)
my $parse_errors  = 0;  # times the header check failed
my $skipped_lines = 0;  # lines discarded while looking for the next header

## report setting: samples with reads below this fraction of the median are listed
my $low_cutoff = 0.25;

while (<INFILE>){
	unless(/^\@\Q$devicename\E/){  ## input file is foobarred here, with data not in sets of 4 lines
		$parse_errors++;
		print "parse error -- after read $seqcnt, expected a header line but got:\n$_";
		$skipped_lines++;  ## the offending line itself is discarded
		my $found = 0;
		while (defined(my $next = <INFILE>)){
			if ($next =~ /^\@\Q$devicename\E/){
				$_ = $next;
				$found = 1;
				last;  ## leaves the inner while only
			}
			$skipped_lines++;
		}
		unless ($found){
			print "Reached end of file without finding another header line; stopping.\n";
			last;  ## leaves the main read loop
		}
		print "Back on track --> $_";
	}
    $seqcnt++;
#    if(!($seqcnt % 10000)){
#	print "$seqcnt\n";
#    }
    chomp($_ = <INFILE>);
    if (s/(TTACAGATCGGAAGAG.*)//){
##          CTTACAGATCGGAAGAGCTCGTATGCCGTCTTCTGCTTG
	## potentially has Illpcr seq at end, so we lop this off
	##
	@ad = split "", $1;
	$adlen = @ad;
	$mseprob++;
    }
    else {
	$adlen = 0;
    }
    $line10 = substr($_, 0, $bclen); ## substr EXPR,OFFSET,LENGTH
    $line9 = substr($_, 0, ($bclen - 1)); # 9 bp barcode
    $line8 = substr($_, 0, ($bclen - 2)); # 8 bp barcode
    if($mids{$line10}){ ## this is a barcode, which I have now pulled off
	s/^$line10//;
	if (/[ATCGN]/) { ## didn't remove it all, there is seq in $_
	    print SEQ "@"."$mids{$line10}"." -- "."$seqcnt\n";
	    print SEQ "$_\n";
	    $goodmid = 1;
	    $goodmidctr++;
	    $exact_written++;
	    $midsctr{$line10}++;
	}
	else {
	    $exact_empty++;
	}
	$whichL = 10;
    }
    elsif($mids{$line9}){ ## this is a barcode, which I have now pulled off
	s/^$line9//;
	if (/[ATCGN]/) { ## didn't remove it all, there is seq in $_
	    print SEQ "@"."$mids{$line9}"." -- "."$seqcnt\n";
	    print SEQ "$_\n";
	    $goodmid = 1;
	    $goodmidctr++;
	    $exact_written++;
	    $midsctr{$line9}++;
	}
	else {
	    $exact_empty++;
	}
	$whichL = 9;
    }
    elsif($mids{$line8}){ ## this is a barcode, which I have now pulled off
	s/^$line8//;
	if (/[ATCGN]/) { ## didn't remove it all, there is seq in $_
	    print SEQ "@"."$mids{$line8}"." -- "."$seqcnt\n";
	    print SEQ "$_\n";
	    $goodmid = 1;
	    $goodmidctr++;
	    $exact_written++;
	    $midsctr{$line8}++;
	}
	else {
	    $exact_empty++;
	}
	$whichL = 8;
    }
    elsif(length $line10 != $bclen){
	$goodmid = 0;  ## this is a special case, where don't have
	## enough remainging sequence to even test
	## for a mid
	$tooshort++;
    }
    else { ## potential mid error
	($line10b, $n10) = correctmid($line10);
	$minN = $n10;
	$whichL = 10;
	if ($minN > 1){
	    ($line9b, $n9) = correctmid($line9);
	    if ($n9 < $minN){
		$minN = $n9;
		$whichL = 9;
	    }
	    if ($minN > 1){
		($line8b, $n8) = correctmid($line8);
		if ($n8 < $minN){
		    $minN = $n8;
		    $whichL = 8;
		}
	    }
	}
	if ($minN > 1){ ## can't correct
	    print CRAP "$_\n";
	    $goodmid = 0;
	    $badmidctr++;
	}
	else { ## has been corrected
	    if ($whichL == 10){
		$line = $line10b;
		s/$line10//;
	    }
	    elsif ($whichL == 9){
		$line = $line9b;
		s/$line9//;
	    }
	    elsif ($whichL == 8){
		$line = $line8b;
		s/$line8//;
	    }
	    if (/[ATCGN]/) { ## didn't remove it all
		print SEQ "@"."$mids{$line}"." -- "."$seqcnt\n";
		print SEQ "$_\n";
		$goodmid = 1;
		$goodmidctr++;
		$corrected_written++;
		$midsctr{$line}++;
	    }
	    else {
		$goodmid = 0;
		$corrected_empty++;
	    }
	}
    }
    chomp($_ = <INFILE>);  ### should be info line that separates seq and qual, often +
    if ($goodmid == 1){
		print SEQ "$_\n";
    }
    chomp($_ = <INFILE>); ### quality line
    if ($goodmid == 1){
	if ($whichL == 10){
	    $seqlength = (length $_) - $bclen - $adlen;
	    $qline = substr($_, $bclen, $seqlength);
	}
	elsif ($whichL == 9){
	    $seqlength = (length $_) - $bclen - $adlen + 1;
	    $qline = substr($_, ($bclen - 1), $seqlength);
	}
	elsif ($whichL == 8){
	    $seqlength = (length $_) - $bclen - $adlen + 2;
	    $qline = substr($_, ($bclen - 2), $seqlength);
	}
	print SEQ "$qline\n";
	$goodmid = 0;
    }
}

my $dropped = $exact_empty + $corrected_empty + $badmidctr + $tooshort;
my $outcome_sum = $exact_written + $corrected_written + $exact_empty
                + $corrected_empty + $badmidctr + $tooshort;

## per-sample numbers (barcode -> sample is 1:1); every sample in the barcode
## file is included, so samples with zero reads count toward the median
my @samples = sort { $midsctr{$b} <=> $midsctr{$a} || $mids{$a} cmp $mids{$b} } keys %midsctr;
my $nsamples = scalar @samples;
my $median = median(values %midsctr);
my $mean = $nsamples ? $goodmidctr / $nsamples : 0;

## per-sample table goes in its own CSV, sorted by reads, highest first
open(SAMPLES, "> samplecounts_$infile.csv") or die "Failed to open sample counts file";
print SAMPLES "sample,reads,pct_of_written,x_median,barcode_plus_site\n";
my @low;  ## samples below the cutoff, as [name, x_median]; stays largest to smallest
foreach my $k (@samples){
    my $n = $midsctr{$k};
    my $x = $median ? $n / $median : undef;
    print SAMPLES join(",", $mids{$k}, $n, pct($n, $goodmidctr),
        defined $x ? sprintf("%.2f", $x) : "NA", $k), "\n";
    push @low, [$mids{$k}, $x] if defined $x && $x < $low_cutoff;
}
close(SAMPLES) or die "Could not close SAMPLES\n";

open(REPORT, "> parsereport_$infile") or die "Failed to open report file";

print REPORT "Total reads processed: $seqcnt\n\n";

print REPORT "READ OUTCOMES (mutually exclusive; counts sum to total reads)\n";
print REPORT outcome_line("Exact barcode match, written to parsed file", $exact_written, $seqcnt);
print REPORT outcome_line("Corrected barcode (edit dist <= 1), written to parsed file", $corrected_written, $seqcnt);
print REPORT outcome_line("Exact barcode match, no sequence left, dropped", $exact_empty, $seqcnt);
print REPORT outcome_line("Corrected barcode, no sequence left, dropped", $corrected_empty, $seqcnt);
print REPORT outcome_line("Uncorrectable barcode, written to miderrors file", $badmidctr, $seqcnt);
print REPORT outcome_line("Too short to test for barcode, dropped", $tooshort, $seqcnt);
if ($outcome_sum != $seqcnt){
    print REPORT "WARNING: outcome categories sum to $outcome_sum but $seqcnt reads were processed\n";
}

print REPORT "\nCOMBINED (sums of the outcomes above)\n";
print REPORT outcome_line("Written to parsed file (exact + corrected)", $goodmidctr, $seqcnt);
print REPORT outcome_line("Not written to parsed file", $dropped, $seqcnt);

print REPORT "\nREAD PROPERTY (overlaps with the outcomes above)\n";
print REPORT outcome_line("3' adapter found and trimmed", $mseprob, $seqcnt);

print REPORT "\nINPUT FILE INTEGRITY (counts only; not read outcomes)\n";
print REPORT "Header check failures (resync events): $parse_errors\n";
print REPORT "Lines discarded while resyncing: $skipped_lines\n";

print REPORT "\nPER-SAMPLE READS WRITTEN (all samples in the barcode file, including any with zero reads)\n";
printf REPORT "Samples: %d   Mean: %.1f   Median: %.1f\n", $nsamples, $mean, $median;
print REPORT "Full per-sample table: samplecounts_$infile.csv\n";

if ($median){
    printf REPORT "\nSAMPLES BELOW %.2fx THE MEDIAN (%d of %d), largest to smallest\n",
        $low_cutoff, scalar @low, $nsamples;
    my $w = 0;
    foreach my $l (@low){ $w = length $l->[0] if length $l->[0] > $w; }
    foreach my $l (@low){
        printf REPORT "%-*s  %.2fx\n", $w, $l->[0], $l->[1];
    }
    print REPORT "(none)\n" unless @low;
}
else {
    print REPORT "\nMedian reads per sample is 0, so reads relative to the median cannot be calculated.\n";
}
close(REPORT) or die "Could not close REPORT\n";


close(SEQ) or die "Could not close SEQ\n";
close(CRAP) or die "Could not close CRAP\n";


##--------- sub routines -----------------##

sub correctmid{
    my $corrected;
    my $min = 100;
    my $mindex = -1;
    for my $i (0 .. $#barcodes){
	$dist = distance($_[0], $barcodes[$i]);
	if($min > $dist){
	    $min = $dist;
	    $mindex = $i;
	}
    }

    return($barcodes[$mindex], $min);
}

## percent of total, 2 decimals (0.00 if total is 0)
sub pct{
    my ($n, $total) = @_;
    return sprintf("%.2f", $total ? 100 * $n / $total : 0);
}

## formats one report line: label, count, and percent of total
sub outcome_line{
    my ($label, $n, $total) = @_;
    return sprintf("%-60s %10d  (%6s%%)\n", "$label:", $n, pct($n, $total));
}

## median of a list of numbers
sub median{
    my @v = sort { $a <=> $b } @_;
    return 0 unless @v;
    my $mid = int(@v / 2);
    return @v % 2 ? $v[$mid] : ($v[$mid - 1] + $v[$mid]) / 2;
}
