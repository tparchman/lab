#!/bin/bash

##########################################################################################
## Raw Illumina data contaminant cleaning (tapioca + fqu_cull)
##
## Usage: clean_contaminants.sh -i <INPUT_FASTQ> -o <OUTPUT_PREFIX> [-t <TAPIOCA_DIR>]
##                              [-x <NAME:DB:PCT>]
##
##   -i  Input FASTQ (plain or .gz)
##   -o  Prefix for all output files (e.g. ELAT_1)
##   -t  Path to the tapioca folder (optional). Default: the folder one level above
##       this script (i.e. this script lives in tapioca/scripts/). The tapioca folder
##       must contain src/tap_contam_analysis and a contaminants/ folder of indexes.
##   -x  Extra contaminant (optional, repeatable), e.g. -x yeast:sc_s288c:80
##
## Example:
##   nohup bash ~/scripts/clean_contaminants.sh \
##       -i 2_KREL25_S1_L001_R1_001.fastq -o ELAT_1 \
##       > ELAT_1.cleaning.log 2>&1 &
##########################################################################################

# --- Default location of the tapioca folder (override with -t) ---
# This script is expected to sit in tapioca/scripts/, so the tapioca folder is one
# level up from wherever this script lives (symlinks are followed).
SCRIPT_DIR=$(dirname "$(readlink -f "${BASH_SOURCE[0]}")")
TAPIOCA_DIR=$(dirname "$SCRIPT_DIR")

# --- Contaminants to search for, written as name:database:pct ---
# "database" is a bowtie2 index inside <tapioca folder>/contaminants (or a full path).
# "pct" is the minimum % of a read that must align for it to be flagged.
CONTAMINANTS=(
    "ill:illumina_oligos:20"
    "phix:phix174:80"
    "ecoli:ecoli-k-12:80"
)

# --- Read the command-line options ---
INPUT_FASTQ=""
PREFIX=""
while getopts "i:o:t:x:" opt; do
    case $opt in
        i) INPUT_FASTQ=$OPTARG ;;
        o) PREFIX=$OPTARG ;;
        t) TAPIOCA_DIR=$OPTARG ;;
        x) CONTAMINANTS+=("$OPTARG") ;;   # extra contaminants join the default list
        *) sed -n '3,20p' "$0"; exit 1 ;;
    esac
done

# --- Make sure the two required options were given ---
if [[ -z $INPUT_FASTQ || -z $PREFIX ]]; then
    sed -n '3,20p' "$0"
    exit 1
fi

# --- Find the tapioca executable and contaminant databases inside the tapioca folder ---
TAPIOCA=$TAPIOCA_DIR/src/tap_contam_analysis
CONTAM_DIR=$TAPIOCA_DIR/contaminants

# --- Start one tapioca search per contaminant; all run at the same time (&) ---
pids=(); names=(); hitfiles=()
for spec in "${CONTAMINANTS[@]}"; do
    # Split "name:database:pct" into its three pieces
    IFS=: read -r name db pct <<< "$spec"

    # A bare database name is looked up in CONTAM_DIR; a full path is used as is
    [[ $db == /* ]] || db=$CONTAM_DIR/$db

    # Each search writes the IDs of the reads it flagged to its own file
    out=${PREFIX}.readstofilter.${name}.txt
    "$TAPIOCA" --db "$db" --pct "$pct" "$INPUT_FASTQ" > "$out" &

    # Remember the job, its name, and its output file for later
    pids+=($!); names+=("$name"); hitfiles+=("$out")
done

# --- Wait for every search to finish; stop here if any of them failed ---
failed=0
for i in "${!pids[@]}"; do
    wait "${pids[$i]}" && echo "${names[$i]} search done" \
        || { echo "ERROR: ${names[$i]} search failed" >&2; failed=1; }
done
[[ $failed -eq 0 ]] || exit 1

# --- Remove every flagged read and write the clean reads ---
# fqu_cull -r keeps only reads whose IDs are NOT in any of the hit files.
CLEAN=${PREFIX}.clean.reads.fastq
fqu_cull -r "${hitfiles[@]}" < "$INPUT_FASTQ" > "$CLEAN" \
    || { echo "ERROR: fqu_cull failed" >&2; exit 1; }
echo "Clean reads written to $CLEAN"

# --- Count reads (4 lines per read) before and after cleaning ---
RAW_N=$(zcat -f "$INPUT_FASTQ" | awk 'END{print int(NR/4)}')
CLEAN_N=$(awk 'END{print int(NR/4)}' "$CLEAN")

# --- Print and save a simple summary, as % of raw reads ---
# These percents can add up to more than 100: a read flagged by more than one
# contaminant is counted in each of those groups.
{
    awk -v n="$CLEAN_N" -v raw="$RAW_N" 'BEGIN { printf "clean: %.3f%%\n", 100*n/raw }'

    for i in "${!names[@]}"; do
        # Count the flagged read IDs in this contaminant's hit file (skip # header lines)
        flagged=$(grep -v '^#' "${hitfiles[$i]}" | cut -f1 | sort -u | wc -l)
        awk -v n="$flagged" -v raw="$RAW_N" -v name="${names[$i]}" \
            'BEGIN { printf "%s: %.3f%%\n", name, 100*n/raw }'
    done
} | tee "${PREFIX}.contam_summary.txt"
