#!/usr/bin/perl

## Creates files for each individual from one or more fastq files. Individuals ids are given in a separate file with one ID per line.

use warnings;

$idfile = shift (@ARGV);
open (IDS, $idfile) or die;
while (<IDS>){
	chomp;
	$fh = "FQ"."$_";
	open ($fh, "> $_".".fastq") or die "Could not write\n";
	$files{$_} = $fh;
}
close (IDS);

$matched = 0;
$unmatched = 0;
$errors = 0;

foreach $in (@ARGV){
	open (IN, $in) or die;
	while (<IN>){
	chomp;
	if (/^\@(\w+)/){
		$id = $1;
		if (defined $files{$id}){
			$flag = 1;
			$matched++;
			$per_sample{$id}++;
			print {$files{$id}} "$_\n";
		}
		else{
			$flag = 0;
			$unmatched++;
			$unmatched_ids{$id}++;
		}
		foreach $i (0..2){
			$line = <IN>;
			if ($flag == 1){
				print {$files{$id}} "$line";
			}
		}
	}
	else{
		$errors++;
		print STDERR "Error -- $_\n";
	}
	}
	close (IN);
}
foreach $id (keys %files){
    close ($files{$id});
}

## Report (STDERR)
$total = $matched + $unmatched;
print STDERR "\n===== Summary =====\n";
print STDERR "Total reads: $total\n";
if ($total > 0){
	printf STDERR "Matched:     %d (%.2f%%)\n", $matched, 100 * $matched / $total;
	printf STDERR "Unmatched:   %d (%.2f%%)\n", $unmatched, 100 * $unmatched / $total;
}
print STDERR "Format errors: $errors\n";

## IDs in the fastq with no entry in the ID file
if (%unmatched_ids){
	print STDERR "\nIDs in fastq but NOT in ID file (ID, read count):\n";
	foreach $id (sort keys %unmatched_ids){
		print STDERR "  $id\t$unmatched_ids{$id}\n";
	}
}

## IDs in the ID file with no reads in the fastq
@empty = sort grep { !defined $per_sample{$_} } keys %files;
if (@empty){
	print STDERR "\nIDs in ID file but with NO reads:\n";
	foreach $id (@empty){
		print STDERR "  $id\n";
	}
}
